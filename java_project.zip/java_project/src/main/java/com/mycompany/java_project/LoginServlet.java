package com.mycompany.java_project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Retrieve form parameters
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            // Database connection parameters
             String url = "jdbc:mysql://localhost/travel";
            String dbUsername = "root";
            String dbPassword = "";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                
                // Establish database connection
                Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);

                // Prepare SQL query to retrieve user_id
                String getUserIdSql = "SELECT user_id FROM registration WHERE username = ? AND password = ?";
                PreparedStatement getUserIdStmt = conn.prepareStatement(getUserIdSql);
                getUserIdStmt.setString(1, username);
                getUserIdStmt.setString(2, password);

                // Execute query to retrieve user_id
                ResultSet rs = getUserIdStmt.executeQuery();

                int userId = 0;
                if (rs.next()) {
                    userId = rs.getInt("user_id");
                } else {
                    // User authentication failed
                    out.println("<h1>Login failed. Invalid username or password.</h1>");
                    return; // Exit method if authentication failed
                }

                // Generate current timestamp for login_time
                Timestamp loginTime = new Timestamp(System.currentTimeMillis());

                // Prepare SQL statement to insert login details into the login table
                String insertLoginSql = "INSERT INTO login (user_id, login_time) VALUES (?, ?)";
                PreparedStatement insertLoginStmt = conn.prepareStatement(insertLoginSql);
                insertLoginStmt.setInt(1, userId);
                insertLoginStmt.setTimestamp(2, loginTime);

                // Execute SQL statement to insert login details
                int rowsAffected = insertLoginStmt.executeUpdate();

                if (rowsAffected > 0) {
                    out.println("<h1>Login successful</h1>");
                     response.sendRedirect("home.html");
                } else {
                    out.println("<h1>Login failed. Error occurred while saving login details.</h1>");
                }

                // Close database resources
                rs.close();
                getUserIdStmt.close();
                insertLoginStmt.close();
                conn.close();
            } catch (SQLException ex) {
                out.println(ex);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
