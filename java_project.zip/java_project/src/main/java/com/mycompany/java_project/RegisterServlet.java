package com.mycompany.java_project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegisterServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        // Retrieve form parameters
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (PrintWriter out = response.getWriter()) {
            // Database connection parameters
            String url = "jdbc:mysql://localhost/travel";
            String dbUsername = "root";
            String dbPassword = "";
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(RegisterServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                // Generate current timestamp
                try ( // Establish database connection
                        Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword)) {
                    // Generate current timestamp
                    Timestamp createdAt = new Timestamp(System.currentTimeMillis());
                    
                    // Prepare SQL statement to insert user details into the Registration table
                    String sql = "INSERT INTO Registration (username, email, password, created_at) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, username);
                        pstmt.setString(2, email);
                        pstmt.setString(3, password);
                        pstmt.setTimestamp(4, createdAt);
                        // Execute SQL statement
                        int rowsAffected = pstmt.executeUpdate();
                        if (rowsAffected > 0) {
                            out.println("<h1>Registration successful!</h1>");
                            response.sendRedirect("login.html");
                        } else {
                            out.println("<h1>Registration failed.</h1>");
                        }
                        // Close resources
                    }
                }
            } catch (SQLException ex) {
                out.println("<h1>Error: " + ex.getMessage() + "</h1>");
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
